package com.imooc.view;

/**
 * 刷新数据接口
 * @author Administrator
 */
public interface IReflashListener {
    public void onReflash();
}
