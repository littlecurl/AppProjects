package cn.edu.heuet.pagingdemofinal_java.db;

/**
 * @ClassName CRUDApi
 * @Author littlecurl
 * @Date 2020/1/8 12:50
 * @Version 1.0.0
 * @Description TODO
 */
public interface CRUDApi {
    public void insertFinished(String errorMsg);
}
