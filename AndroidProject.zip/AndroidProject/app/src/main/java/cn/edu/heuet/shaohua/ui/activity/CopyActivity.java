package cn.edu.heuet.shaohua.ui.activity;

import cn.edu.heuet.shaohua.R;

import cn.edu.heuet.shaohua.common.MyActivity;

/**
 *    author : Android 轮子哥
 *    github : https://github.com/getActivity/AndroidProject
 *    time   : 2018/10/18
 *    desc   : 可进行拷贝的副本
 */
public final class CopyActivity extends MyActivity {

    @Override
    protected int getLayoutId() {
        return R.layout.copy_activity;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}