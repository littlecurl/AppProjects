package com.example.customtitlebar.router;

public class MyRouter {
    public static final String ACTIVITY_MAIN = "/activity/main";
    public static final String ACTIVITY_SEARCH = "/activity/search";
}
