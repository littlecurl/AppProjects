package com.imooc.view;
//加载更多数据的回调接口
public interface ILoadListener{
    public void onLoad();
}
