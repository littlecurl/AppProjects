package cn.edu.heuet.buttomnavigation;

import android.os.Bundle;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

import cn.edu.heuet.buttomnavigation.adapter.MyFragmentStateAdapter;
import cn.edu.heuet.buttomnavigation.fragment.Fragment_1_Home;
import cn.edu.heuet.buttomnavigation.fragment.Fragment_2_Track;
import cn.edu.heuet.buttomnavigation.fragment.Fragment_3_Message;
import cn.edu.heuet.buttomnavigation.fragment.Fragment_4_Mine;
import cn.edu.heuet.buttomnavigation.utils.NGGuidePageTransformer;
import cn.edu.heuet.buttomnavigation.widget.CustomBottomNavigation;

import static cn.edu.heuet.buttomnavigation.widget.CustomBottomNavigation.radioButtonIds;

public class MainActivity extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 构造 4 个 Fragment
        List<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(new Fragment_1_Home());
        fragmentList.add(new Fragment_2_Track());
        fragmentList.add(new Fragment_3_Message());
        fragmentList.add(new Fragment_4_Mine());

        // 将FragmentList传递给FragmentStateAdapter绑定 4 个Fragment视图到ViewPager
        MyFragmentStateAdapter myFragmentStateAdapter = new MyFragmentStateAdapter(this, fragmentList);
        final ViewPager2 viewPager2 = findViewById(R.id.activity_main_viewPager2);
        viewPager2.setAdapter(myFragmentStateAdapter);
        viewPager2.setCurrentItem(0);
        // 阻止左右滑动
        viewPager2.setUserInputEnabled(false);
        // 切换动画-淡入淡出（可以不使用淡入淡出，默认是左右切换）
        viewPager2.setPageTransformer(new NGGuidePageTransformer());
        // 自定义底部导航，其实是个RadioGroup
        CustomBottomNavigation customBottomNavigation = findViewById(R.id.customBottomNavigation);
        // 点击底部按钮监听事件
        // 切换到对应的页面
        customBottomNavigation.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == radioButtonIds.get(0)){
                    // 如果不带第二个参数 false 会显示中间页面
                    // 比如，从第一个页面跳到第三个页面时，会显示第二个页面
                    // 因此，带上false，不显示滚动页面
                    // viewPager2.setCurrentItem(0);
                    viewPager2.setCurrentItem(0,false);
                }
                if(checkedId == radioButtonIds.get(1)){
                    viewPager2.setCurrentItem(1,false);
                }
                if(checkedId == radioButtonIds.get(2)){
                    viewPager2.setCurrentItem(2,false);
                }
                if(checkedId == radioButtonIds.get(3)){
                    viewPager2.setCurrentItem(3,false);
                }
            }
        });
    }


}
