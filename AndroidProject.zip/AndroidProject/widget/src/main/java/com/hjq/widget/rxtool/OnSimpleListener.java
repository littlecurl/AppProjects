package com.hjq.widget.rxtool;

/**
 *
 * @author Vondear
 * @date 2017/9/22
 */

public interface OnSimpleListener {
    void doSomething();
}
