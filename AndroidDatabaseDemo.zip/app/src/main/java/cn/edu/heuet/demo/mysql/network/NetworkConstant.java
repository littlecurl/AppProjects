package cn.edu.heuet.demo.mysql.network;

public class NetworkConstant {
    public static final String BASE_URL           = "http://220b1a3541.iok.la/";
    public static final String INSERT_URL         = "student/insert";
    public static final String BATCH_INSERT_URL   = "student/insert/batch";
    public static final String DELETED_URL        = "student/delete";
    public static final String UPDATE_URL         = "student/update";
    public static final String QUERY_URL          = "student/query";
}
