package cn.edu.heuet.buttomnavigation.fragment;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import java.util.List;
import java.util.Objects;

import cn.edu.heuet.buttomnavigation.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_1_Home extends Fragment {

    public Fragment_1_Home() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        return view;
    }

}
