package cn.edu.heuet.buttomnavigation.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.edu.heuet.buttomnavigation.R;
import cn.edu.heuet.buttomnavigation.utils.MyUIUtils;

import static androidx.appcompat.widget.ListPopupWindow.MATCH_PARENT;

/**
 * @ClassName CustomBottomNavigation.java
 * @Author littlecurl
 * @Date 2019-12-16 12:30:00
 * @Version 1.0.0
 * @Description 自定义底部导航栏的
 */

public class CustomBottomNavigation extends RadioGroup {

    Context context;
    public static List<Integer> radioButtonIds = new ArrayList<>();
    public CustomBottomNavigation(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initRadioGroup(context);
        initRadioButton(context);
    }

    private void initRadioGroup(Context context) {
        setPadding(0, MyUIUtils.dip2px(context, 5), 0, 0);
        setLayoutParams(getLayoutParams(MATCH_PARENT, MyUIUtils.dip2px(context, 56)));
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);
    }

    private void initRadioButton(final Context context) {
        List<Integer> imageList = Arrays.asList(
                R.drawable.selector_home,
                R.drawable.selector_pond,
                R.drawable.selector_message,                  // message占位
                R.drawable.selector_person
        );
        List<String> titleList = Arrays.asList(
                getResources().getString(R.string.home),
                getResources().getString(R.string.track),
                getResources().getString(R.string.message),
                getResources().getString(R.string.mine)
        );
        for (int i = 0; i < 4; i++) {
            RadioButton radioButton = new RadioButton(context);
            // 设置id
            int id = MyUIUtils.generateViewId();
            radioButtonIds.add(id);
            radioButton.setId(id);

            radioButton.setGravity(Gravity.CENTER);
            radioButton.setLayoutParams(getLayoutParams(0, MATCH_PARENT, 1.0F));
            // 设置图片
            Drawable drawable = getResources().getDrawable(imageList.get(i));
            // 左 *上* 右下
            drawable.setBounds(0, 0, MyUIUtils.dip2px(context, 25), MyUIUtils.dip2px(context, 25));
            radioButton.setCompoundDrawables(null, drawable, null, null);
            radioButton.setButtonDrawable(null);
            // 设置文字
            radioButton.setText(titleList.get(i));
            // 添加到RadioGroup
            addView(radioButton);
        }
    }

    // RadioGroup父布局设置宽、高
    // LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT
    public LayoutParams getLayoutParams(int width, int height) {
        LayoutParams params = new LayoutParams(width, height);
        return params;
    }

    // RadioButton子布局设置宽、高、权重
    // LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 1.0f
    public LayoutParams getLayoutParams(int width, int height, float weight) {
        LayoutParams params = new LayoutParams(width, height, weight);
        return params;
    }
}
