package cn.edu.heuet.shaohua.wxapi;

import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 *    author : Android 轮子哥
 *    github : https://github.com/getActivity/AndroidProject
 *    time   : 2019/05/06
 *    desc   : 微信登录回调（请注意这个 Activity 放置的包名要和当前项目的包名保持一致，否则将不能正常回调）
 */
public final class WXEntryActivity extends WXCallbackActivity {}