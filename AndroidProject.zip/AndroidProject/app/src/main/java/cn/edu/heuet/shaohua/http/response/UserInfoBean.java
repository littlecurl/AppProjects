package cn.edu.heuet.shaohua.http.response;

/**
 *    author : Android 轮子哥
 *    github : https://github.com/getActivity/AndroidProject
 *    time   : 2019/12/07
 *    desc   : 用户信息
 */
public final class UserInfoBean {

}